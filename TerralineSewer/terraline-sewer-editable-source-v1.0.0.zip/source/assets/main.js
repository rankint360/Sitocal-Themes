/* Terraline Sewer — main.js (v=20261116a). Loaded with defer. No dependencies.
   Content is fully visible without JS; JS only adds the .js class and enhancements. */
(function () {
  "use strict";
  var doc = document.documentElement;
  doc.classList.add("js");
  var body = document.body;

  /* ---------- Mobile menu (panel sits outside <header>) ---------- */
  var toggle = document.querySelector("[data-menu-toggle]");
  var panel = document.getElementById("mobile-menu");

  function setHeaderHeight() {
    var h = document.querySelector(".site-header");
    if (h) doc.style.setProperty("--hdr-h", h.offsetHeight + "px");
  }

  function openMenu() {
    if (!panel || !toggle) return;
    setHeaderHeight();
    panel.hidden = false;
    // next frame so the transition runs after display change
    requestAnimationFrame(function () { panel.classList.add("is-open"); });
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Close menu");
    body.classList.add("menu-open");
  }

  function closeMenu(returnFocus) {
    if (!panel || !toggle) return;
    panel.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open menu");
    body.classList.remove("menu-open");
    setTimeout(function () { if (!panel.classList.contains("is-open")) panel.hidden = true; }, 220);
    if (returnFocus) toggle.focus();
  }

  if (toggle && panel) {
    toggle.addEventListener("click", function (e) {
      e.preventDefault();
      toggle.getAttribute("aria-expanded") === "true" ? closeMenu(false) : openMenu();
    });
    panel.addEventListener("click", function (e) {
      var link = e.target.closest("a");
      if (link) closeMenu(false);
    });
    window.addEventListener("resize", function () {
      if (window.innerWidth >= 1024 && body.classList.contains("menu-open")) closeMenu(false);
    });
  }

  /* Collapsible groups inside the mobile panel */
  document.querySelectorAll("[data-group-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var list = document.getElementById(btn.getAttribute("aria-controls"));
      var open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!open));
      if (list) list.hidden = open;
    });
  });

  /* ---------- Desktop dropdowns (click + hover + keyboard) ---------- */
  var items = document.querySelectorAll(".nav__item");
  function closeAll(except) {
    items.forEach(function (it) {
      if (it === except) return;
      it.classList.remove("is-open");
      var b = it.querySelector(".nav__btn");
      if (b) b.setAttribute("aria-expanded", "false");
    });
  }
  items.forEach(function (it) {
    var btn = it.querySelector(".nav__btn");
    if (!btn) return;
    var t;
    btn.addEventListener("click", function () {
      var open = it.classList.toggle("is-open");
      btn.setAttribute("aria-expanded", String(open));
      closeAll(it);
    });
    it.addEventListener("mouseenter", function () {
      if (!window.matchMedia("(hover:hover)").matches) return;
      clearTimeout(t); closeAll(it);
      it.classList.add("is-open"); btn.setAttribute("aria-expanded", "true");
    });
    it.addEventListener("mouseleave", function () {
      if (!window.matchMedia("(hover:hover)").matches) return;
      t = setTimeout(function () { it.classList.remove("is-open"); btn.setAttribute("aria-expanded", "false"); }, 160);
    });
    it.addEventListener("focusout", function (e) {
      if (!it.contains(e.relatedTarget)) { it.classList.remove("is-open"); btn.setAttribute("aria-expanded", "false"); }
    });
  });
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".nav__item")) closeAll(null);
  });

  /* Esc closes everything */
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (body.classList.contains("menu-open")) closeMenu(true);
    var open = document.querySelector(".nav__item.is-open");
    if (open) { closeAll(null); var b = open.querySelector(".nav__btn"); if (b) b.focus(); }
  });

  /* ---------- Symptom checker (tabs) ---------- */
  document.querySelectorAll("[data-symptoms]").forEach(function (root) {
    var tabs = root.querySelectorAll("[data-symptom]");
    var panels = root.querySelectorAll(".symptom-panel");
    function show(id) {
      tabs.forEach(function (t) { t.setAttribute("aria-selected", String(t.getAttribute("data-symptom") === id)); t.tabIndex = t.getAttribute("data-symptom") === id ? 0 : -1; });
      panels.forEach(function (p) { var on = p.id === id; p.classList.toggle("is-active", on); });
    }
    tabs.forEach(function (t, i) {
      t.addEventListener("click", function () { show(t.getAttribute("data-symptom")); });
      t.addEventListener("keydown", function (e) {
        var k = e.key, n = null;
        if (k === "ArrowDown" || k === "ArrowRight") n = tabs[(i + 1) % tabs.length];
        if (k === "ArrowUp" || k === "ArrowLeft") n = tabs[(i - 1 + tabs.length) % tabs.length];
        if (n) { e.preventDefault(); n.focus(); show(n.getAttribute("data-symptom")); }
      });
    });
    if (tabs[0]) show(tabs[0].getAttribute("data-symptom"));
  });

  /* ---------- Reveal on scroll ---------- */
  var reveals = document.querySelectorAll(".reveal");
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!("IntersectionObserver" in window) || reduce) {
    reveals.forEach(function (el) { el.classList.add("is-in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    reveals.forEach(function (el) { io.observe(el); });
  }

  /* ---------- TOC active state (last heading above 30% of viewport) ---------- */
  var tocLinks = document.querySelectorAll(".toc a[href^='#']");
  if (tocLinks.length) {
    var heads = [];
    tocLinks.forEach(function (a) { var h = document.getElementById(a.getAttribute("href").slice(1)); if (h) heads.push([h, a]); });
    var ticking = false;
    var update = function () {
      ticking = false;
      var cur = null, line = window.innerHeight * 0.3;
      heads.forEach(function (p) { if (p[0].getBoundingClientRect().top < line) cur = p[1]; });
      tocLinks.forEach(function (a) { a.classList.toggle("is-active", a === cur); });
    };
    window.addEventListener("scroll", function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }
  /* TOC: open on desktop, collapsed on phones */
  document.querySelectorAll("details.toc-m").forEach(function (d) { d.open = window.innerWidth >= 1024; });
  /* Close mobile TOC after a jump */
  document.querySelectorAll("details.toc-m a").forEach(function (a) {
    a.addEventListener("click", function () {
      if (window.innerWidth < 1024) { var d = a.closest("details"); if (d) d.open = false; }
    });
  });

  /* ---------- Footer year ---------- */
  document.querySelectorAll("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

  setHeaderHeight();
  window.addEventListener("resize", setHeaderHeight);
})();
