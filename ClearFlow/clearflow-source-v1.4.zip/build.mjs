import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
fs.cpSync('site','dist',{recursive:true});
execFileSync(process.execPath,['export-sitocal.mjs'],{stdio:'inherit'});
