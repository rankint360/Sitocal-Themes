import http from 'node:http';import fs from 'node:fs';import path from 'node:path';
const root=path.resolve('dist');
http.createServer((req,res)=>{let f=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!f.startsWith(root+path.sep)&&f!==root){res.writeHead(403).end();return}if(fs.existsSync(f)&&fs.statSync(f).isDirectory())f=path.join(f,'index.html');if(!fs.existsSync(f)){res.statusCode=404;f=path.join(root,'404.html')}res.setHeader('Content-Type',({'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.json':'application/json','.svg':'image/svg+xml'})[path.extname(f)]||'text/plain');res.end(fs.readFileSync(f))}).listen(4174,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:4174'));

