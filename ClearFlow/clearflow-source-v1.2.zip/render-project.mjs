// Offline reference build: node render-project.mjs PROJECT_DIRECTORY OUTPUT_DIRECTORY
// PROJECT_DIRECTORY contains project.json, pages/*.json, assets/styles.css + app.js + favicon.svg.
import fs from 'node:fs';import path from 'node:path';import {renderDocument} from './sitocal-contract.mjs';
const [input,output]=process.argv.slice(2);if(!input||!output)throw Error('Usage: node render-project.mjs PROJECT_DIRECTORY OUTPUT_DIRECTORY');
const source=path.resolve(input),destination=path.resolve(output);if(source===destination||source.startsWith(destination+path.sep)||destination.startsWith(source+path.sep))throw Error('Use separate input/output directories');
const contained=(root,p)=>{if(typeof p!=='string'||p.includes('\\')||p.split('/').includes('..')||path.isAbsolute(p))throw Error('Invalid relative path');const full=path.resolve(root,p);if(!full.startsWith(root+path.sep))throw Error('Path escapes project');return full};
const project=JSON.parse(fs.readFileSync(path.join(source,'project.json'),'utf8'));if(project.contract!=='sitocal.portable-project/1'||!Array.isArray(project.pages))throw Error('Invalid project contract');
const outputs=new Set();for(const p of project.pages){if(!/^\/(?:[a-z0-9-]+\/)*$/.test(p.path))throw Error('Unsupported route');const file=(p.path.slice(1)||'')+'index.html';if(outputs.has(file))throw Error('Duplicate route');outputs.add(file);const doc=JSON.parse(fs.readFileSync(contained(source,p.document),'utf8'));const target=contained(destination,file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,renderDocument(doc,{preset:project.preset}));}
fs.mkdirSync(path.join(destination,'assets'),{recursive:true});for(const name of ['styles.css','app.js','favicon.svg'])fs.copyFileSync(path.join(source,'assets',name),path.join(destination,'assets',name));
fs.writeFileSync(path.join(destination,'robots.txt'),'User-agent: *\nDisallow: /\n');
console.log(`Built ${outputs.size} project-owned pages. Demo behavior and noindex retained.`);
