// Reference adapter for this package's explicit, versioned document format.
// Does not execute theme-provided JavaScript. Sitocal must enforce its own
// import trust policy and map documents into its native project persistence.
export const contract='sitocal.portable-theme/1';
const tags=new Set('html head meta title link body a div span header nav button main section h1 h2 h3 h4 p b em strong small article aside ul li footer form label input select option textarea details summary br img figure figcaption svg defs pattern path linearGradient stop circle rect text'.split(' '));
const voids=new Set(['meta','link','input','br','img']);
const attrs=new Set('lang charset name content rel href type media class id role title tabindex aria-label aria-expanded aria-controls aria-current aria-hidden aria-labelledby aria-describedby viewBox width height fill stroke stroke-width stroke-dasharray d x y x2 y2 cx cy r rx offset stop-color patternUnits font-size font-family letter-spacing for placeholder required maxlength autocomplete value selected xmlns src alt loading decoding'.split(' '));
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function safeUrl(value){return typeof value==='string'&&!/[\u0000-\u0020\\]/.test(value)&&(/^(\/(?!\/)|#)/.test(value)||/^https:\/\//.test(value));}
export function visit(node,fn){fn(node);if(node.children)node.children.forEach(n=>visit(n,fn));}
export function validateDocument(doc){
 if(doc.contract!==contract||!Array.isArray(doc.nodes))throw Error('Unsupported document contract');
 const ids=new Set();let count=0;
 const walk=(n,depth=0)=>{if(depth>80||++count>20000)throw Error('Document too large');if(!n||typeof n.id!=='string'||ids.has(n.id))throw Error('Missing or duplicate node ID');ids.add(n.id);
 if(n.type==='text'){if(typeof n.value!=='string'||n.value.length>10000)throw Error('Invalid text');return}
 if(n.type!=='element'||!tags.has(n.tag)||!Array.isArray(n.children))throw Error('Unsupported element: '+n.tag);
 for(const [k,v] of Object.entries(n.attrs||{})){if(!(attrs.has(k)||/^data-(section|service|demo)$/.test(k)))throw Error(`Unsupported attribute: ${k}`);if(typeof v!=='string')throw Error('Attribute must be a string');if(k==='src'&&!(v.startsWith('/assets/')&&safeUrl(v)))throw Error('Unsafe image path');if(k==='href'&&!safeUrl(v))throw Error('Unsafe URL');if((k==='fill'||k==='stroke')&&/url\(/i.test(v)&&!/^url\(#[\w-]+\)$/.test(v))throw Error('External SVG reference');}
 if(n.tag==='link'&&!['stylesheet','icon'].includes(n.attrs.rel))throw Error('Unsupported link relation');
 if(voids.has(n.tag)&&n.children.length)throw Error('Void element has children');n.children.forEach(c=>walk(c,depth+1));};
 doc.nodes.forEach(n=>walk(n));return true;
}
export function findNode(doc,id){let found;doc.nodes.forEach(n=>visit(n,x=>{if(x.id===id)found=x}));if(!found)throw Error(`Unknown node ${id}`);return found}
export function setText(doc,id,value){const n=findNode(doc,id);if(n.type!=='text'||typeof value!=='string'||value.length>10000)throw Error('Invalid text edit');n.value=value;}
export function setAttribute(doc,id,key,value){const n=findNode(doc,id);const allowed=['href','placeholder','aria-label','title'];if(n.type!=='element'||!allowed.includes(key)||typeof value!=='string'||(key==='href'&&!safeUrl(value)))throw Error('Invalid attribute edit');n.attrs[key]=value;}
export function setMetadata(doc,kind,value){if(typeof value!=='string'||value.length>1000)throw Error('Invalid metadata');const binding=doc.metadata?.find(m=>m.kind===kind);if(!binding)throw Error('Unknown metadata field');const n=findNode(doc,binding.nodeId);if(kind==='title')setText(doc,n.id,value);else if(kind==='description'&&n.tag==='meta'&&n.attrs.name==='description')n.attrs.content=value;else throw Error('Invalid metadata binding');}
function mainNode(doc){let main;doc.nodes.forEach(n=>visit(n,x=>{if(x.tag==='main')main=x}));if(!main)throw Error('Missing main');return main}
export function sections(doc){return mainNode(doc).children.filter(n=>n.type==='element');}
export function moveSection(doc,id,index){const main=mainNode(doc);const list=sections(doc);if(!Number.isInteger(index)||index<0||index>=list.length)throw Error('Invalid section position');const node=list.find(n=>n.id===id);if(!node)throw Error('Unknown section');list.splice(list.indexOf(node),1);list.splice(index,0,node);main.children=list;}
export function setSectionVisible(doc,id,visible){if(typeof visible!=='boolean')throw Error('Expected boolean');const n=sections(doc).find(n=>n.id===id);if(!n)throw Error('Unknown section');n.hidden=!visible;}
export function duplicateSection(doc,id,suffix){if(!/^[a-z0-9-]{1,32}$/.test(suffix))throw Error('Invalid clone suffix');const main=mainNode(doc),source=sections(doc).find(n=>n.id===id);if(!source)throw Error('Unknown section');const copy=structuredClone(source),map=new Map(),existing=new Set();doc.nodes.forEach(n=>visit(n,x=>existing.add(x.id)));
 visit(copy,n=>{n.id+='--'+suffix;if(existing.has(n.id))throw Error('Clone ID collision');if(n.attrs?.id)map.set(n.attrs.id,n.attrs.id+'--'+suffix)});
 visit(copy,n=>{if(!n.attrs)return;for(const [k,v]of Object.entries(n.attrs)){if(k==='id')n.attrs[k]=map.get(v);if(['for','aria-controls','aria-labelledby','aria-describedby'].includes(k))n.attrs[k]=v.split(' ').map(x=>map.get(x)||x).join(' ');if(k==='href'&&v.startsWith('#')&&map.has(v.slice(1)))n.attrs[k]='#'+map.get(v.slice(1));if(['fill','stroke'].includes(k))n.attrs[k]=v.replace(/url\(#([\w-]+)\)/g,(m,key)=>map.has(key)?`url(#${map.get(key)})`:m)}});
 main.children.splice(main.children.indexOf(source)+1,0,copy);return copy.id;
}
export function renderDocument(doc,{preset={tokens:{},layout:'default'},runtime=true}={}){
 validateDocument(doc);
 const allowedTokens=new Set(['--green','--lime','--paper','--ink','--muted','--line']);const css=Object.entries(preset.tokens||{}).map(([k,v])=>{if(!allowedTokens.has(k)||!/^#[0-9a-f]{6}$/i.test(v))throw Error('Invalid design token');return `${k}:${v}`}).join(';');
 if(!['default','reversed','compact'].includes(preset.layout))throw Error('Invalid layout');
 const render=n=>{if(n.hidden)return '';if(n.type==='text')return escape(n.value);const a={...n.attrs};if(n.tag==='body')a.class=((a.class||'')+' variant-'+preset.layout).trim();let inner=n.children.map(render).join('');if(n.tag==='head')inner+=`<style>:root{${css}}</style>`;if(n.tag==='body'&&runtime)inner+='<script defer src="/assets/app.js"></script>';return `<${n.tag}${Object.entries(a).map(([k,v])=>` ${k}="${escape(v)}"`).join('')}>`+(voids.has(n.tag)?'':inner+`</${n.tag}>`)};
 return '<!doctype html>'+doc.nodes.map(render).join('');
}

