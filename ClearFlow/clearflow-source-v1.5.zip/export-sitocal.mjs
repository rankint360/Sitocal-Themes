import fs from 'node:fs';
import crypto from 'node:crypto';
import {contract,validateDocument,visit,sections,renderDocument} from './sitocal-contract.mjs';
const root='dist';const read=p=>fs.readFileSync(p,'utf8');const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2));
const original=JSON.parse(read(root+'/sitocal-theme.json'));
const decode=s=>s.replace(/&(amp|lt|gt|quot|#39);/g,(_,x)=>({amp:'&',lt:'<',gt:'>',quot:'"','#39':"'"}[x]));
// This tokenizer handles only this generator's controlled HTML, not arbitrary
// third-party HTML. The receiving builder must validate JSON independently.
function parse(html,pageId){
 const nodes=[],stack=[{children:nodes}],voids=new Set(['meta','link','input','br','img']);let i=0;
 html=html.replace(/<!doctype[^>]*>/i,'') .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,'').replace(/<script\b[^>]*>[\s\S]*?<\/script>/g,'');
 for(const tok of html.matchAll(/<[^>]+>|[^<]+/g)){const s=tok[0];if(s.startsWith('</')){const tag=s.slice(2,-1);if(stack.pop().tag!==tag)throw Error('Unbalanced HTML: '+tag);continue}if(s.startsWith('<')){const tag=s.match(/^<([\w-]+)/)?.[1];if(!tag)throw Error('Unknown token');const attrs={};for(const a of s.slice(tag.length+1,-1).matchAll(/([\w:-]+)(?:="([^"]*)")?/g))attrs[a[1]]=decode(a[2]||'');const n={id:`${pageId}-n${++i}`,type:'element',tag,attrs,children:[]};stack.at(-1).children.push(n);if(!voids.has(tag)&&!s.endsWith('/>'))stack.push(n);}else stack.at(-1).children.push({id:`${pageId}-n${++i}`,type:'text',value:decode(s)});
 }if(stack.length!==1)throw Error('Unclosed HTML');return nodes;
}
const presets=[
 {id:'clearflow',name:'ClearFlow',layout:'default',tokens:{'--green':'#173f35','--lime':'#d8ed8c','--paper':'#f7f8f2','--ink':'#172b2a','--muted':'#5d6f6b','--line':'#dce3d8'}},
 {id:'harbor-pro',name:'Harbor Pro',layout:'reversed',tokens:{'--green':'#18334f','--lime':'#f2c293','--paper':'#f7f6f2','--ink':'#182d43','--muted':'#586b7d','--line':'#d8dfe6'}},
 {id:'clearwater-local',name:'Clearwater Local',layout:'compact',tokens:{'--green':'#16556a','--lime':'#bce9f2','--paper':'#f5fafb','--ink':'#163c4b','--muted':'#526e78','--line':'#d1e5ea'}}
];
fs.mkdirSync(root+'/sitocal/pages',{recursive:true});fs.mkdirSync(root+'/sitocal/variations',{recursive:true});
const pageEntries=[];
for(const p of original.pages){const id=p.path==='/'?'home':p.path.replace(/^\/|\/$/g,'').replaceAll('/','--');const doc={contract,id,path:p.path,title:p.title,nodes:parse(read(root+'/'+p.file),id)};validateDocument(doc);
 const fields=[];const walk=(n,parent)=>{if(n.type==='text'&&n.value.trim()&&parent?.tag!=='text')fields.push({id:n.id,nodeId:n.id,property:'value',control:'text',label:n.value.trim().slice(0,70),maxLength:10000});if(n.type==='element'){for(const k of ['href','placeholder','aria-label','title'])if(n.attrs[k]!==undefined&&!(n.tag==='link'))fields.push({id:n.id+'-'+k,nodeId:n.id,property:'attrs.'+k,control:k==='href'?'url':'text',label:`${n.tag} ${k}`});n.children.forEach(c=>walk(c,n));}};doc.nodes.forEach(n=>walk(n));
 doc.sections=sections(doc).map(n=>({id:n.id,type:n.attrs['data-section']||'content',label:n.attrs['data-section']||n.attrs.class||'Content',canMove:true,canDuplicate:true,canHide:true}));
 // Metadata is explicit; edit these text nodes/attributes through the native adapter.
 const metadata=[];doc.nodes.forEach(n=>visit(n,x=>{if(x.tag==='title')metadata.push({kind:'title',nodeId:x.children[0]?.id,property:'value'});if(x.tag==='meta'&&x.attrs.name==='description')metadata.push({kind:'description',nodeId:x.id,property:'attrs.content'})}));doc.metadata=metadata;
 write(`${root}/sitocal/pages/${id}.json`,doc);write(`${root}/sitocal/pages/${id}.fields.json`,fields);
 pageEntries.push({...p,id,document:`sitocal/pages/${id}.json`,fields:`sitocal/pages/${id}.fields.json`});
 // Canonical HTML is rendered from the same editable document used by imports.
 fs.writeFileSync(root+'/'+p.file,renderDocument(doc,{preset:presets[0]}));
 if(id==='home')for(const preset of presets){fs.mkdirSync(`${root}/variations/${preset.id}`,{recursive:true});fs.writeFileSync(`${root}/variations/${preset.id}/index.html`,renderDocument(doc,{preset}));}
}
write(root+'/sitocal/variations/presets.json',presets);
fs.copyFileSync('sitocal-contract.mjs',root+'/sitocal/reference-adapter.mjs');
write(root+'/sitocal/editor.json',{contract,sourceOfTruth:'Project-owned page documents after import',controls:['text','url','color','section-order','section-visible','section-duplicate','preset'],metadataControls:['title','description'],persistence:'Implemented by Sitocal; never write changes back to the theme origin',assetPolicy:'Copy into project storage and rewrite URLs',runtime:{mode:'demo-only',source:'assets/app.js',instruction:'Review and bundle as trusted builder code; never dynamically execute downloaded modules.'},limits:{images:'Stock images and their captions are preserved with their bundled assets.',collections:'Services and locations are materialized pages/cards, not live synchronized collections.',globalContent:'Header/footer copies must be promoted to shared components by the Sitocal adapter.'}});
const files=[];const walk=dir=>{for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory())walk(p);else if(e.name!=='sitocal-theme.json')files.push({path:p.slice(root.length+1),bytes:fs.statSync(p).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')})}};walk(root);
write(root+'/sitocal-theme.json',{schemaVersion:contract,id:original.id,name:original.name,version:'1.5.0',category:original.category,entry:'index.html',demo:true,compatibility:'Requires a Sitocal adapter for sitocal.portable-theme/1; not verified against the Sitocal repository.',editor:'sitocal/editor.json',presets:'sitocal/variations/presets.json',referenceAdapter:'sitocal/reference-adapter.mjs',pages:pageEntries,styles:['assets/styles.css'],runtime:'assets/app.js',files,previewRoutes:presets.map(p=>({id:p.id,path:`/variations/${p.id}/`})),importMode:'copy-validate-map'});
console.log(`Exported ${pageEntries.length} editable documents and ${presets.length} presets.`);

