document.addEventListener('submit', event => {
  const form = event.target;
  if (!form.matches('[data-demo-form]')) return;
  event.preventDefault();
  const status = form.querySelector('[role="status"]');
  if (status) status.textContent = 'Demo complete. Nothing was sent or saved.';
}, true);
