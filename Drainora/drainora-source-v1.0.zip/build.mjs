import fs from 'node:fs';import path from 'node:path';
const capture=JSON.parse(fs.readFileSync('source/capture.json','utf8'));
fs.mkdirSync('dist',{recursive:true});fs.cpSync('source/assets','dist/assets',{recursive:true});
for(const p of capture.pages){let html=fs.readFileSync('source/pages/'+p.file,'utf8');
html=html.replaceAll('Jupiter Drainers','Drainora').replace(/<!-- This site is hosted on Netlify\.[\s\S]*?-->/g,'').replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/g,'').replace(/<link rel="canonical"[^>]*>/g,'').replace(/<meta property="og:url"[^>]*>/g,'').replace(/content="index, follow"/g,'content="noindex, nofollow"');
for(const a of capture.assets)html=html.split(a.url).join('/'+a.file);
html=html.replace(/((?:src|href)\s*=\s*["'])(?:\.\.\/|\.\/)*assets\//g,'$1/assets/');
html=html.replace('</body>','<script src="/assets/js/demo.js"></script>\n</body>');
fs.mkdirSync(path.dirname('dist/'+p.file),{recursive:true});fs.writeFileSync('dist/'+p.file,html);}
fs.mkdirSync('dist/assets/js',{recursive:true});fs.copyFileSync('demo.js','dist/assets/js/demo.js');
fs.writeFileSync('dist/robots.txt','User-agent: *\nDisallow: /\n');
fs.writeFileSync('dist/_headers','/*\n  X-Content-Type-Options: nosniff\n  X-Robots-Tag: noindex, nofollow\n');
fs.writeFileSync('dist/theme.json',JSON.stringify({id:'drainora',name:'Drainora',version:'1.0.0',category:'Drain cleaning',demo:true,source:'Faithful renamed static clone',pages:capture.pages,editorCompatibility:'Raw HTML/CSS; requires a Sitocal HTML adapter. Not the ClearFlow portable-document contract.'},null,2));
console.log(`Built Drainora: ${capture.pages.length} pages with original styles and scripts.`);
