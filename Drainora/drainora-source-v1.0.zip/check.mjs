import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const capture=JSON.parse(fs.readFileSync('source/capture.json','utf8'));let links=0;
const classes=s=>[...s.matchAll(/\bclass\s*=\s*(["'])(.*?)\1/gs)].map(m=>m[2]);
for(const p of capture.pages){const html=fs.readFileSync('dist/'+p.file,'utf8'),source=fs.readFileSync('source/pages/'+p.file,'utf8');assert.deepEqual(classes(html),classes(source),'Original layout classes changed');assert.ok(html.includes('Drainora'));assert.ok(!html.includes('Jupiter Drainers'));assert.ok(!html.includes('jupiterplumber.com'));assert.ok(html.includes('/assets/js/demo.js'));
for(const m of html.matchAll(/\b(href|src)\s*=\s*(["'])(.*?)\2/gi)){const value=m[3];if(/^(#|tel:|mailto:|data:)/.test(value))continue;assert.ok(!/^https?:/.test(value),'External asset/link '+value);let target='dist'+value;if(!/\.[a-z0-9]+$/i.test(target))target=target.replace(/\/$/,'')+'/index.html';assert.ok(fs.existsSync(target),'Missing '+target);links++;}}
for(const a of capture.assets){assert.equal(crypto.createHash('sha256').update(fs.readFileSync('dist/'+a.file)).digest('hex'),a.sha256,'Original asset changed: '+a.file)}
for(const p of ['dist/assets/js/main.js','dist/assets/js/demo.js'])new Function(fs.readFileSync(p,'utf8'));
console.log(`PASS: ${capture.pages.length} pages; ${links} local references; original class lists and ${capture.assets.length} asset hashes unchanged; Drainora branding; demo script syntax.`);
