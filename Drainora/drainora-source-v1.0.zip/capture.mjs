import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const origin='https://theme1-preview.netlify.app';
const queue=['/'],seen=new Set(),pages=[],assets=new Map();
fs.mkdirSync('source/pages',{recursive:true});fs.mkdirSync('source/assets',{recursive:true});
async function get(url){const r=await fetch(url);if(!r.ok)throw Error(`${r.status}: ${url}`);return Buffer.from(await r.arrayBuffer())}
while(queue.length){const route=queue.shift();if(seen.has(route))continue;seen.add(route);if(seen.size>60)throw Error('Unexpected page count');const html=(await get(origin+route)).toString('utf8');
const filename=route==='/'?'index.html':route.replace(/^\/|\/$/g,'')+'/index.html';fs.mkdirSync(path.dirname('source/pages/'+filename),{recursive:true});fs.writeFileSync('source/pages/'+filename,html);pages.push({route,file:filename});
for(const m of html.matchAll(/\b(href|src)\s*=\s*(["'])(.*?)\2/gi)){const value=m[3];if(/^(#|tel:|mailto:|data:)/i.test(value))continue;const u=new URL(value,origin+route);if(u.origin===origin&&!u.pathname.includes('assets/')&&!path.extname(u.pathname)){if(!seen.has(u.pathname))queue.push(u.pathname);}else if(m[1]==='src'||/\.(css|png|svg|jpg|webp|woff2?)(\?|$)/i.test(value)){const key=u.origin===origin?'assets/'+u.pathname.split('assets/')[1]:'assets/vendor/'+(u.pathname.includes('@tailwindcss')?'tailwind-browser.js':path.basename(u.pathname));assets.set(u.href,key);}}
console.log('Captured',route);}
for(const [url,file]of assets){const data=await get(url);fs.mkdirSync(path.dirname('source/'+file),{recursive:true});fs.writeFileSync('source/'+file,data);console.log('Asset',file,data.length)}
fs.writeFileSync('source/capture.json',JSON.stringify({origin,capturedAt:new Date().toISOString(),pages,assets:[...assets].map(([url,file])=>({url,file,sha256:crypto.createHash('sha256').update(fs.readFileSync('source/'+file)).digest('hex')}))},null,2));
