import fs from 'node:fs';
import assert from 'node:assert/strict';

const theme = JSON.parse(fs.readFileSync('dist/theme.json', 'utf8'));
const routes = new Set(theme.pages.map(page => page.route));
let references = 0;
for (const page of theme.pages) {
  const html = fs.readFileSync('dist/' + page.file, 'utf8');
  assert.ok(html.includes(theme.name), 'Missing brand on ' + page.route);
  assert.ok(!/pest\s*pros|action\s*=\s*["']mailto:/i.test(html), 'Original brand or live action on ' + page.route);
  for (const [, , url] of html.matchAll(/\b(?:href|src)\s*=\s*(["'])(.*?)\1/gi)) {
    if (url.startsWith('#') || url.startsWith('data:')) continue;
    assert.ok(url.startsWith('/'), 'Nonlocal URL: ' + url + ' on ' + page.route);
    const target = url.split(/[?#]/)[0].replace(/\/$/, '') || '/';
    assert.ok(routes.has(target) || fs.existsSync('dist' + target), 'Missing target: ' + url + ' on ' + page.route);
    references++;
  }
  for (const [form] of html.matchAll(/<form\b[^>]*>/gi)) {
    assert.match(form, /data-demo-form method="dialog"/);
    assert.ok(!/\baction\s*=|\bnetlify\b/i.test(form));
  }
}
if (theme.variant === 'fieldworks') {
  const home = fs.readFileSync('dist/index.html', 'utf8');
  assert.match(home, /Find how they’re getting in\./);
  assert.match(home, /id="field-guide"/);
  assert.match(home, /<details open>/);
}
new Function(fs.readFileSync('dist/assets/demo.js', 'utf8'));
console.log('Verified ' + theme.pages.length + ' pages, ' + references + ' local links and asset references, branding and inert form actions.');
