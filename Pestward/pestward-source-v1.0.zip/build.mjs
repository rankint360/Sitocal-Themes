import fs from 'node:fs';
import path from 'node:path';

const theme = JSON.parse(fs.readFileSync('theme.json', 'utf8'));
const capture = JSON.parse(fs.readFileSync('source/capture.json', 'utf8'));
const fieldworks = theme.variant === 'fieldworks';
fs.mkdirSync('dist/assets', {recursive:true});
fs.cpSync('source/assets', 'dist/assets', {recursive:true});
fs.copyFileSync('demo.js', 'dist/assets/demo.js');
if (fieldworks) fs.copyFileSync('fieldworks.css', 'dist/assets/fieldworks.css');

function localize(tag) {
  return tag.replace(/\b(href|src)\s*=\s*(["'])(.*?)\2/gi, (match, attr, quote, raw) => {
    let value = raw.replaceAll('&amp;', '&');
    const asset = capture.assets.find(entry => entry.url === value);
    if (asset) value = '/' + asset.file;
    value = value
      .replace(/^(?:\.\.\/|\.\/)*assets\//, '/assets/')
      .replace(/^https:\/\/theme2preview\.netlify\.app(?=\/|$)/, '')
      .replace(/^\/services\/odor-control-removal\b/, '/services/odor-control-and-removal')
      .replace(/^\/services\/rodent-baiting-trapping\b/, '/services/rodent-baiting-and-trapping');
    if (/^(tel:|mailto:)/i.test(value)) value = '/contact';
    if (/^javascript:/i.test(value)) value = '#';
    return attr + '=' + quote + (value || '/') + quote;
  });
}
const sampleNote = '<p class="text-sm mt-3">Demo form. Use sample details. Nothing is sent or saved.</p>';
for (const page of capture.pages) {
  let html = fs.readFileSync('source/pages/' + page.file, 'utf8')
    .replace(/<!-- This site is hosted on Netlify\.[\s\S]*?-->/gi, '')
    .replace(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<link\b[^>]*rel=["']canonical["'][^>]*>/gi, '')
    .replace(/<meta\b[^>]*(?:og:url|name=["']robots["'])[^>]*>/gi, '')
    .replace(/pest\s*pros/gi, theme.name)
    .replace(/(?:sales|support)@(?:pestpros|Pestward(?: Fieldworks)?)\.com/gi, 'contact@example.com')
    .replace(/877[\s.-]*123[\s.-]*4567/g, '(212) 555-0142')
    .replace(/<(?:a|img|script|link)\b[^>]*>/gi, localize)
    .replace(/<form\b([^>]*)>/gi, (_, attrs) => '<form data-demo-form method="dialog"' + attrs.replace(/\s+(?:action|method|enctype|name|data-netlify|netlify)(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi, '') + '>' + sampleNote)
    .replace(/<\/form>/gi, '<p role="status" class="text-sm"></p></form>')
    .replace(/Fill out the form below and we.ll get back to you within 24 hours\./gi, 'Preview an inquiry using sample details.')
    .replace(/(id=["']testimonials["'][^>]*>)/i, '$1<p class="container mx-auto px-6 pt-4 text-sm">Sample testimonials for this demonstration.</p>')
    .replace(/<\/head>/i, '<meta name="robots" content="noindex,nofollow">\n' + (fieldworks ? '<link rel="stylesheet" href="/assets/fieldworks.css">\n' : '') + '</head>')
    .replace(/<\/body>/i, '<script src="/assets/demo.js"></script>\n</body>');
  if (fieldworks && page.route === '/') {
    const home = fs.readFileSync('fieldworks-home.html', 'utf8');
    const hero = /<section class="py-24 md:py-34">[\s\S]*?<\/section>/;
    if (!hero.test(html)) throw Error('Original homepage hero was not found');
    html = html.replace(hero, () => home)
      .replace(/<section id="testimonials"[\s\S]*?<\/section>/, '');
  }
  const output = 'dist/' + page.file;
  fs.mkdirSync(path.dirname(output), {recursive:true});
  fs.writeFileSync(output, html);
}
// Preserve the original testimonial spacing without suggesting a customer affiliation.
const quoteMark = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 32"><path fill="#4f46e5" d="M12 9h14v12H18c0 4-2 7-6 8zm23 0h14v12h-8c0 4-2 7-6 8z"/></svg>';
fs.writeFileSync('dist/assets/vendor/nike.svg', quoteMark);
fs.writeFileSync('dist/404.html', '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Page not found | '+theme.name+'</title><main><h1>Page not found</h1><p><a href="/">Return to '+theme.name+'</a></p></main></html>');
fs.writeFileSync('dist/robots.txt', 'User-agent: *\nDisallow: /\n');
fs.writeFileSync('dist/_headers', '/*\n  X-Content-Type-Options: nosniff\n  X-Robots-Tag: noindex, nofollow\n  Referrer-Policy: strict-origin-when-cross-origin\n');
fs.writeFileSync('dist/theme.json', JSON.stringify({...theme, version:'1.0.0', category:'Rodent control', demo:true, pages:capture.pages}, null, 2));
console.log('Built ' + theme.name + ': ' + capture.pages.length + ' pages.');
