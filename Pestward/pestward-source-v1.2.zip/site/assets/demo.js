document.addEventListener('submit', (event) => {
  const form = event.target;
  if (!form.matches('[data-demo-form]')) return;
  event.preventDefault();
  form.querySelector('[role="status"]').textContent = 'Demo complete. Nothing was sent or saved.';
}, true);
